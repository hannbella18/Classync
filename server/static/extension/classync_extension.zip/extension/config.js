// config.js - base URL for Classync backend

// Default to your local Flask backend on port 5001
const DEFAULT_API = "http://localhost:5001";

// Allow override from DevTools if you ever use ngrok again:
//   localStorage.setItem("API_BASE", "https://your-id.ngrok-free.dev");
const API_BASE = (localStorage.getItem("API_BASE") || DEFAULT_API)
  .trim()
  .replace(/\/+$/, "");

// Expose for background.js
self.API_BASE = API_BASE;
